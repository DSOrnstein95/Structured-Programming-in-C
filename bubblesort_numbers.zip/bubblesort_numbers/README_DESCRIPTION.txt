Bubblesort is a sorting algorithm that sorts numerical values located in an array, in a lesser to greater value arrangement. 
The memory address of the first adres is read by a pointer variable and the second adres by another pointer variable. By storing the memory address the pointer can be 
dereferenced to check its contents. If the number on the next_adres is greater than the number on the current_adres then another function will be called by reference to 
the memory address contents in value. This process (loop) will repeat automatically until the array is sorted. 