#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#define size 20

void string_sort (char **strPtr, int count)
{
  void swap (char **strPtr1, char **strPtr2);	//function prototype
  //print the unsorted string array

  printf ("Printing the unsorted array of strings\n");
     puts("");
  for (int n = 0; n < 20; n++)
    {
      printf ("City or country[%d] = %s\n", n+1, strPtr[n]);
    }
  printf ("\n");
  printf ("Preparing to sort string array in alphabetical order\n");
  puts ("");			//skip a line
  puts ("Sorted array in alphabetical order: ");
  //sort the array and then print
  for (int i = 0; i < 20; i++)
    {
      for (int j = i + 1; j < 20; j++)
        {
            if (strcmp (strPtr[i], strPtr[j]) > 0)
            {
                swap (&strPtr[i], &strPtr[j]);	//send the address of pointer pointing to pointer to function swap
            }
        }

      printf ("City or country[%d] = %s\n", i + 1, strPtr[i]);
    }

}

void swap (char **strPtr1, char **strPtr2)
{				//function swap does not return a value, and expects the address of a pointer-to-a-pointer as its argument
  char *temp = *strPtr1;	//copy the address of strPtr1 and store address into temp
  *strPtr1 = *strPtr2;		//swap address of strPtr2 with strPtr1,
  *strPtr2 = temp;		//assign address of temp (which is address of strPtr1) to strPtr2
}

int main (int argc, char *argv[] )
{

  void string_sort (char **strPtr, int count);
  void swap (char **strPtr1, char **strPtr2 );



  char *str[size] =
    { "Aruba", "Amsterdam", "Oranjestad", "St-Maarten", "Willemstad", "Delft",
      "Kralendijk", "Den Haag", "Rotterdam", "Duitsland", "Berlin", "Frankrijk",
      "Bonaire", "Curacao", "Belgie", "Noorwegen", "Zweden", "Indonesie", "Ukraine", "Rusland", "Turkije" "\0" };

  string_sort (str, size);


  return 0;
}

